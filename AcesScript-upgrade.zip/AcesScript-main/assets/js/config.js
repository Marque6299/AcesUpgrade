// Site switches. Ads render only for slots that have a real AdSense unit ID.
window.ACES_CONFIG = {
  ads: {
    enabled: true,
    client: 'ca-pub-6978764838614552',
    slots: { rail: '', infeed: '', end: '' },      // paste real ad-unit IDs from AdSense > Ads > By ad unit
    railPages: ['scripts', 'checklist'],           // add 'errands' only if your client policy allows ads beside customer data
    endPages: ['scripts', 'checklist', 'links'],
    inFeedEvery: 10, inFeedMax: 3
  }
};
