(() => {
  'use strict';
  const cfg = (window.ACES_CONFIG || {}).ads || {};
  const track = (n, p) => window.acesTrack?.(n, p);
  const page = () => document.body.dataset.page || 'scripts';
  const unit = id => `<span class="ad-label">Advertisement</span><ins class="adsbygoogle" style="display:block" data-ad-client="${cfg.client}" data-ad-slot="${id}" data-ad-format="auto" data-full-width-responsive="true"></ins>`;
  const make = (cls, key, id) => { const a = document.createElement('aside'); a.className = `ad-slot ${cls}`; a.dataset.slot = key; a.setAttribute('aria-label', 'Advertisement'); a.innerHTML = unit(id); return a; };

  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { io.unobserve(e.target); fill(e.target); } }), { rootMargin: '400px 0px' });

  function fill(slot) {
    const ins = slot.querySelector('ins.adsbygoogle');
    if (!ins || ins.dataset.adsbygoogleStatus || slot.getBoundingClientRect().width === 0) return;   // never push into a zero-width box
    new MutationObserver((_, mo) => {
      const s = ins.getAttribute('data-ad-status');
      if (s === 'filled') { slot.classList.add('is-filled'); track('ads.slot.filled', { slot: slot.dataset.slot, page: page() }); view(slot); mo.disconnect(); }
      if (s === 'unfilled') { slot.classList.add('is-empty'); track('ads.slot.unfilled', { slot: slot.dataset.slot, page: page() }); mo.disconnect(); }
    }).observe(ins, { attributes: true, attributeFilter: ['data-ad-status'] });
    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); track('ads.slot.requested', { slot: slot.dataset.slot, page: page() }); }
    catch { slot.classList.add('is-empty'); }
  }
  function view(slot) {          // own "viewable" proxy: >=50% visible for 1 s
    let t; const v = new IntersectionObserver(([e]) => { clearTimeout(t); if (e.isIntersecting) t = setTimeout(() => { track('ads.slot.viewable', { slot: slot.dataset.slot, page: page() }); v.disconnect(); }, 1000); }, { threshold: .5 });
    v.observe(slot);
  }
  function inFeed(module) {      // display-only injection; script data untouched
    const subs = [...module.querySelectorAll(':scope > .script-card-sub')];
    if (subs.length < 20) return;
    for (let i = cfg.inFeedEvery - 1, n = 0; i < subs.length && n < cfg.inFeedMax; i += cfg.inFeedEvery, n++)
      subs[i].after(make('ad-infeed', 'infeed-' + (n + 1), cfg.slots.infeed));
  }
  function showFor() {
    const p = page();
    document.querySelectorAll('.ad-rail').forEach(s => { s.hidden = !(cfg.railPages || []).includes(p); });
    document.querySelectorAll('.ad-end').forEach(s => { s.hidden = !(cfg.endPages || []).includes(p); });
  }
  window.AcesAds = {
    init() {
      const s = cfg.slots || {};
      if (!cfg.enabled || window.ACES_CONSENT?.ads === false) return;
      if (s.rail) document.querySelector('.app-body').append(make('ad-rail', 'rail', s.rail));
      if (s.end) document.querySelector('.main-page').insertBefore(make('ad-end', 'end', s.end), document.querySelector('.site-footer'));
      if (s.infeed) document.querySelectorAll('.script-module').forEach(inFeed);
      showFor();
      document.querySelectorAll('.ad-slot').forEach(x => io.observe(x));
      document.addEventListener('aces:page', showFor);
    }
  };
})();
