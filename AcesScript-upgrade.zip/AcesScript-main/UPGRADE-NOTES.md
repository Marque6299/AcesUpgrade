# ACES upgrade notes (built from AcesUpgradePlan.md)

## What changed
| Phase | Done |
|---|---|
| **P0 Integrity** | App now renders `data/scripts-list.json` and `data/checklist.json` (single source). `scripts-data.js` / `checklist-data.js` are *generated* file:// fallbacks (`node tools/build-data.mjs`). `node tools/verify-text.mjs` checks the SHA-256 baseline on both (passes: 474 entries, 564 cards). The JSON is byte-identical to the upload. |
| **P1 Ads** | Old AdManager, inline ad CSS, dead overlay code and the two 728x90 units removed. New `assets/js/ads.js`: lazy, measured, no polling, no `push` monkey-patch; rail / in-feed / end slots; labelled; reserved height; hidden while searching. **Nothing renders until you paste real unit IDs in `assets/js/config.js`** (the old IDs looked like placeholders). Footer is now static, inside the scroll area. |
| **P2 Tracking** | `assets/js/tracker.js` (local-first, whitelisted props only, no text/PII, honours Do Not Track). `data-track` on static controls; hooks for copy ok / blocked / fail, card click/reset, tabs, search, channel, page load, ad request/fill/viewable. Read it with `acesMetrics.top('scripts.card.copy_ok')` or `acesMetrics.export()` in the console. |
| **P4 UX (lite)** | `assets/css/aces-upgrade.css` token layer (light + dark), solid channel colours, neutral cards with channel edge, no hover shift, 14px body, dashed/solid placeholder states, "2 of 3 fields / Ready" chip, static New/Updated markers, visible two-tone focus ring (+ forced-colors), reduced motion. Keyboard: cards and placeholders are focusable (Enter fills/copies), `/` search, `Esc` clear, `Alt+1..5` pages, `aria-current`, live region for "Copied". `<button><a>` fixed, inputs labelled, logos relative. |
| **P5 (partial)** | Search covers card content (accent/look-alike folding, index copy only) with result count; placeholder aliases (`[Brand]`/`[BRAND]`/`[Brand Name]`/`[our Brand]`, `[Agent name]`...) share one value; unfilled-token warning (`##x##`, `XYZ`, `XX`, `CUSTOMER NAME`); agent name persisted; "new since last visit" replaces the 7-day blink; one shared state manager. |

## UX skills applied
- **ux-audit** (code tier): baseline inventory of the original = 121 colours, 16 font sizes, 13 radii, 33 shadows, 11% token adoption; the plan's findings were adopted as the register.
- **ux-restyle**: scope locked to look, not flows; plan tokens measured. Failing white-text pairs were derived darker: brand `#2c7be5` (4.14:1) -> `#1d63c6` (5.75:1); voice `#0f9d8a` (3.38:1) -> `#0b7a6b` (5.24:1); ok `#1f9d63` (3.46:1) -> `#17784a` (5.49:1). All text/UI pairs in `aces-upgrade.css` measured >= 4.4:1 (UI) / 4.5:1 (text), light and dark.
- **ux-design / ux-review**: card anatomy, states (empty/filled/ready/copied/blocked/loading/error), microcopy.

## Decisions for the content owner (plan §2.5)
1. Refund timing: the JSON says "5", the old JS copy said "6". JSON wins; confirm it is the right policy.
2. The `<strong>` add-on disclaimer on *CEP-Discuss Solution & Gain Agreement* exists only in the old JS copy. It is not in the JSON; add it there if it should return.
3. Curly quotes/dashes are restored in copied text (canonical). Add a paste-safe toggle only if a downstream tool mangles them.

## Account side (cannot be done in code)
Create real ad units and paste IDs in `assets/js/config.js`; keep Auto Ads off or Anchor-only; confirm the `*.netlify.app` host status in AdSense; consent banner (Funding Choices) if EEA/UK visitors; confirm client policy before enabling `errands` in `railPages`.

## Not built in this pass
Admin editor (P3), tab grouping + header rework, favourites/recents, PWA/offline worker, brand auto-fill selector, stats dashboard page, content sanitiser (only needed once an editor exists), step/command tracking inside the checklist. Everything else in the plan is untouched.

## Not verified
Written without a browser. Do a live pass: tab through header -> tabs -> card -> copy, check the dark/light card colours on each page, resize 1440 -> 390 px, and compare clipboard text with the JSON for the NBSP, Cyrillic and `<br>` samples.
