// node tools/verify-text.mjs [file...]  -> exit 1 if any script text differs from the baseline
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const BASELINE = 'dfe17a2456964833977f43c59ab88cb6012a8c4ae7f46dc56f987c0ff1bfccb4';
const files = process.argv.slice(2);
if (!files.length) files.push('data/scripts-list.json', 'scripts-data.js');
let bad = 0;
for (const f of files) {
  let t = readFileSync(f, 'utf8').replace(/^\uFEFF/, '');
  if (f.endsWith('.js')) t = t.slice(t.indexOf('['), t.lastIndexOf(']') + 1);
  const d = JSON.parse(t);
  const h = createHash('sha256').update(JSON.stringify(d.map(s => [s.id, s.category, s.title, s.description, s.cards.map(c => c.content)]))).digest('hex');
  if (h === BASELINE) console.log(`✔ ${f}: text intact (${d.length} entries)`);
  else { console.error(`✖ ${f}: script text differs from baseline\n  got ${h}`); bad = 1; }
}
process.exit(bad);
